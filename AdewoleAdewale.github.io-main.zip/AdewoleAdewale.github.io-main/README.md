# AdewoleAdewale.github.io
/_config.yml
/README.md
/index.md
/_layouts/default.html
/_layouts/home.html
/_includes/header.html
/_includes/footer.html
/_includes/profile-card.html
/assets/css/styles.css
/assets/js/main.js
/assets/img/profile-placeholder.jpg
/projects.md
/contact.md
