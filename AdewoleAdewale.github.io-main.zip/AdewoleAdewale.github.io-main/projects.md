---
layout: default
title: Projects
---


<h1 class="text-2xl font-bold">Projects</h1>


<ul class="mt-4 space-y-4">
<li>
<h3 class="font-semibold">PayQuick — Mobile Wallet</h3>
<p class="text-sm">A secure wallet built with Xamarin for Android and iOS. Features offline sync and bank integration.</p>
</li>
</ul>
