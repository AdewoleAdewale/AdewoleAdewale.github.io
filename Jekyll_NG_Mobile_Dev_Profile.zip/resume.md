---
layout: default
title: Resume
---

# Adewole Adewale
**Mobile & Web App Developer**  
Lagos, Nigeria

## Profile
Developer specializing in cross-platform apps using Xamarin, .NET, and MAUI.

## Skills
- C#, .NET, XAML
- Xamarin.Forms, .NET MAUI
- Azure, GitHub Actions, SQL

## Experience
- Senior Mobile Developer at LagosTech (2022—Present)
- Mobile Developer at InnovateNaija (2020—2022)

## Education
- B.Sc. Computer Science, University of Lagos

## Certifications
- Microsoft Certified: .NET Developer
- Azure Fundamentals (AZ-900)
