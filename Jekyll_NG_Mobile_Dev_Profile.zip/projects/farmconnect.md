---
layout: project
title: FarmConnect — Agricultural Extension App
tech: .NET MAUI, Azure Functions, CosmosDB
---

Offline-first app for agricultural agents.