---
layout: project
title: PayQuick — Mobile Wallet
tech: Xamarin.Forms, .NET 6, Azure SQL, SignalR
---

Cross-platform wallet app supporting Nigerian banks.