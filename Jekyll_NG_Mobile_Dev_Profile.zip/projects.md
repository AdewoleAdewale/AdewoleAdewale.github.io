---
layout: default
title: Projects
---

# Featured Projects

- [PayQuick](/projects/payquick)
- [FarmConnect](/projects/farmconnect)
